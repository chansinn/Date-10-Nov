package org.exante.report.pojo;

import java.io.Serializable;

public class Address implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String addressLine1;
	private String addressLine2;
	private boolean isAccountValid;
	private boolean isAccountActive;
	private boolean isSystemDown;

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public boolean isAccountValid() {
		return isAccountValid;
	}

	public void setAccountValid(boolean isAccountValid) {
		this.isAccountValid = isAccountValid;
	}

	public boolean isAccountActive() {
		return isAccountActive;
	}

	public void setAccountActive(boolean isAccountActive) {
		this.isAccountActive = isAccountActive;
	}

	public boolean isSystemDown() {
		return isSystemDown;
	}

	public void setSystemDown(boolean isSystemDown) {
		this.isSystemDown = isSystemDown;
	}
	
}
