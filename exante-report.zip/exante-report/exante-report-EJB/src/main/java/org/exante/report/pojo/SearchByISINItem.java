package org.exante.report.pojo;

import java.io.Serializable;

public class SearchByISINItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String amount;
	private String placeOfTrade;
	private String locked;
	private boolean isSecurityNameValid;
	private boolean isISINNumberValid;
	private boolean isSystemDown;
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getPlaceOfTrade() {
		return placeOfTrade;
	}
	public void setPlaceOfTrade(String placeOfTrade) {
		this.placeOfTrade = placeOfTrade;
	}
	public String getLocked() {
		return locked;
	}
	public void setLocked(String locked) {
		this.locked = locked;
	}
	public boolean isSecurityNameValid() {
		return isSecurityNameValid;
	}
	public void setSecurityNameValid(boolean isSecurityNameValid) {
		this.isSecurityNameValid = isSecurityNameValid;
	}
	public boolean isISINNumberValid() {
		return isISINNumberValid;
	}
	public void setISINNumberValid(boolean isISINNumberValid) {
		this.isISINNumberValid = isISINNumberValid;
	}
	public boolean isSystemDown() {
		return isSystemDown;
	}
	public void setSystemDown(boolean isSystemDown) {
		this.isSystemDown = isSystemDown;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
