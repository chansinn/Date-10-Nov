package org.exante.report.pojo;

import java.io.Serializable;

public class UploadedPDF implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String filePath;

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

}
