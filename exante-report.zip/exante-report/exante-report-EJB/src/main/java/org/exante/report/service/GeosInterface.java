package org.exante.report.service;

import java.util.List;

import javax.ejb.Remote;

import org.exante.report.pojo.Address;
import org.exante.report.pojo.NameSearchItem;
import org.exante.report.pojo.SearchByISINItem;
import org.exante.report.pojo.UploadedPDF;

@Remote
public interface GeosInterface {
	public Address getAccountInfo(String accountNumber)throws Exception;
	public List<NameSearchItem> securitySearchByName(String securityName)throws Exception;
	public List<SearchByISINItem> securitySearchByISIN(String securityName)throws Exception;
    public List<UploadedPDF> fileLinks(String xmlFile) throws Exception; 
}
