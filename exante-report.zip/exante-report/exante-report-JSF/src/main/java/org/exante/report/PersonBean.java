package org.exante.report;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.event.AjaxBehaviorEvent;

import org.exante.report.service.GeosInterface;

import java.io.Serializable;

@ManagedBean(name="person")
@SessionScoped
public class PersonBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@EJB GeosInterface geosService;
	String personName;
	String prompt;
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getPrompt() {
		return prompt;
	}
	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}
	 
public String hello(){
	System.out.println("hi this is managed bean");
	//geosService.helloEjb();
	return "hi";
	//geosServiceImpl.webServiceAdress();
}
}
