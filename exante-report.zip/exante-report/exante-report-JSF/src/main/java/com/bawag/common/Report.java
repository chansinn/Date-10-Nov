package com.bawag.common;
import java.util.ArrayList;
import java.util.Arrays;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "report", eager = true)
@SessionScoped
public class Report {

	private String isin;
	private String menge;
	private String handelsplatz;
	private String beleg;

	private static final ArrayList<Report> mockData = 
			new ArrayList<Report>(
			Arrays.asList(
					new Report("DE0005557508", "100,000 Stk.", "XETRA-Frankfurt", "Beleg"),
					new Report("AT0000743059", "500,000 Stk.", "WIENER BOERSE", "Beleg"),
					new Report("AT000000FCC2", "800,000 Stk.", "XETRA-Frankfurt", "Beleg")
					));

	public ArrayList<Report> getMockData() {
		return mockData;
	}
	
	public String getIsin() {
		return isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}
	
	public String getMenge() {
		return menge;
	}

	public void setMenge(String menge) {
		this.menge = menge;
	}

	public String getHandelsplatz() {
		return handelsplatz;
	}

	public void setHandelsplatz(String handelsplatz) {
		this.handelsplatz = handelsplatz;
	}

	public String getBeleg() {
		return beleg;
	}

	public void setBeleg(String beleg) {
		this.beleg = beleg;
	}

	public Report() {
	}

	public Report(String isin,String menge, String handelsplatz, String beleg) {
		this.isin = isin;
		this.menge = menge;
		this.handelsplatz = handelsplatz;
		this.beleg = beleg;
	}

}