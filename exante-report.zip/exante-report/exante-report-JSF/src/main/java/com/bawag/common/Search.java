package com.bawag.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionListener;

@ManagedBean(name = "searchBean", eager = true)
@SessionScoped
public class Search {

	private String wertpapiertyp;
	private String isin;
	private String wertpapiertitel;

	/*private static final ArrayList<Search> mockData = new ArrayList<Search>(
			Arrays.asList(
					new Search("bktien", "SG1CD5000001",
							"Advanced holding Ltd.: Reg.Shs(Post Consolidation) oN"),
					new Search("Aktien", "US0078651082",
							"Aeropostale Inc.: Registered Shared DL-.01"),
					new Search("cktien", "GB00B7LHJ340",
							"Andes Energia PLC: Reg.Shares(Post. Cons.) LS-.10")));

	public ArrayList<Search> getMockData() {
		return mockData;
	}*/

	public Search() {
	}

	public Search(String wertpapiertyp, String isin, String wertpapiertitel) {
		this.wertpapiertyp = wertpapiertyp;
		this.isin = isin;
		this.wertpapiertitel = wertpapiertitel;
	}

	public String getWertpapiertyp() {
		return wertpapiertyp;
	}

	public void setWertpapiertyp(String wertpapiertyp) {
		this.wertpapiertyp = wertpapiertyp;
	}

	public String getWertpapiertitel() {
		return wertpapiertitel;
	}

	public void setWertpapiertitel(String wertpapiertitel) {
		wertpapiertitel = wertpapiertitel;
	}

	public String getIsin() {
		return isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}

}