package com.bawag.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import org.exante.report.pojo.Address;
import org.exante.report.service.GeosInterface;

@ManagedBean(name = "mockDataRecords", eager = true)
@SessionScoped
public class OrderBean implements Serializable {

	@EJB
	GeosInterface geosService;
	@Inject
	Address address;

	private static final long serialVersionUID = 1L;

	private String errorMessage;

	private List<Search> orderArrayList;

	private String depotnummer;

	private String accountInformation1;

	private String accountInformation2;

	private String securityName;

	public OrderBean() {
		orderArrayList = new ArrayList<Search>();
	}

	public List<Search> getOrderArrayList() {
		/*
		 * System.out.println("securityName"+securityName);
		 * if(securityName==null){ orderArrayList = new ArrayList<Search>(); }
		 */
		return orderArrayList;

	}

	// sort by Wertpapiertyp (ascending order)
	public String sortByAscending() {
		Collections.sort(orderArrayList, new Comparator<Search>() {
			@Override
			public int compare(Search o1, Search o2) {
				return o1.getWertpapiertyp().compareTo(o2.getWertpapiertyp());
			}
		});
		return null;
	}

	// sort by Wertpapiertyp (descending order)
	public String sortByDescending() {
		Collections.sort(orderArrayList, new Comparator<Search>() {
			@Override
			public int compare(Search o1, Search o2) {
				return o2.getWertpapiertyp().compareTo(o1.getWertpapiertyp());
			}
		});
		return null;
	}

	// Ajax call to populate the account information
	public void getAccountInformation() {

		try {
			System.out.println("depotnummer=" + depotnummer);
			Address add = geosService.getAccountInfo(depotnummer);
			boolean isAccountValid = add.isAccountValid();
			boolean isAccountActive = add.isAccountActive();
			String accountInfoLine1 = add.getAddressLine1();
			String accountInfoLine2 = add.getAddressLine2();
			
			if (depotnummer == "" || depotnummer == null) {
				errorMessage = "";
				accountInformation1 = "";
				accountInformation2 = "";
			} else if (!isAccountValid) {
				errorMessage = "Depotnummer ungültig (Account does not exist)";
				accountInformation1 = "";
				accountInformation2 = "";
			} else if (!isAccountActive) {
				errorMessage = "Depot geschlossen (Account inactive)";
				accountInformation1 = "";
				accountInformation2 = "";
			} else if (accountInfoLine1.length() > 0
					|| accountInfoLine2.length() > 0) {
				errorMessage = "";
				accountInformation1 = accountInfoLine1;
				accountInformation2 = accountInfoLine2;
			}
		} catch (Exception e) {
			errorMessage = "System is not available, please try again! ";
			accountInformation1 = "";
			accountInformation2 = "";
		}

	}

	public List<Search> getSearchByNameOrIsin() {
		System.out.println("searchByNameOrIsin******************************");
		System.out.println("DeopNummer---searchByNameOrIsin------"
				+ depotnummer);
		System.out.println("securityNames---earchByNameOrIsin------"
				+ securityName);
		Search[] orderList1 = {
				new Search("bktien", "SG1CD5000001",
						"Advanced holding Ltd.: Reg.Shs(Post Consolidation) oN"),
				new Search("Aktien", "US0078651082",
						"Aeropostale Inc.: Registered Shared DL-.01"),
				new Search("bktien", "SG1CD5000001",
						"Advanced holding Ltd.: Reg.Shs(Post Consolidation) oN"),
				new Search("Aktien", "US0078651082",
						"Aeropostale Inc.: Registered Shared DL-.01"),
				new Search("bktien", "SG1CD5000001",
						"Andes Energia PLC: Reg.Shares(Post. Cons.) LS-.10") };
		orderArrayList = new ArrayList<Search>(Arrays.asList(orderList1));
		return orderArrayList;
	}

	public String getdepotnummer() {
		return depotnummer;
	}

	public void setdepotnummer(String depotnummer) {
		this.depotnummer = depotnummer;
	}

	public String getSecurityName() {
		return securityName;
	}

	public void setSecurityName(String securityName) {
		this.securityName = securityName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getAccountInformation2() {
		return accountInformation2;
	}

	public void setAccountInformation2(String accountInformation2) {
		this.accountInformation2 = accountInformation2;
	}

	public String getAccountInformation1() {
		return accountInformation1;
	}

	public void setAccountInformation1(String accountInformation1) {
		this.accountInformation1 = accountInformation1;
	}

}