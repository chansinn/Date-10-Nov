package com.bawag.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "validate", eager = true)
@SessionScoped
public class Validation implements Serializable {

	private static final long serialVersionUID = 1L;

	// sort by Wertpapiertyp (ascending order)
	public Boolean validateDepotnummer() {
		return true;
	}

}