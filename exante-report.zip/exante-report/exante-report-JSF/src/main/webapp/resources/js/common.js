var totalAmount= "12,455";
var ifBuySelected = false;
var ifSellOrTransferSelected = false;

function validateDepotnummer(element) {
	var accNumber = null;
	if(element!= null && element!=undefined){
		accNumber = element.value;
	}
	/*
	 * Check if the account number is exist or not and is active and update
	 * accNoDoesNotExist and accIsInactive accordingly here
	 */
	var accNoDoesNotExist = true;
	var accIsInactive = true;
	var depotnummerIsValid = true;

	/*if (accNoDoesNotExist) {
		alert("Depotnummer ungultig");
	}
	if (accIsInactive) {
		alert("Depot geschlossen");
	}*/

	if (accNoDoesNotExist != true && accIsInactive != true) {
		depotnummerIsValid = true;
	}

	if (depotnummerIsValid) {
		/* Ajax call for account information based on the deponummer */
		var accInformation = "";
		// Activate �Gesch�ftsart� (type of transaction), "Wertpapiertitel oder
		// ISIN"
		var transTypeEle = document.getElementById("infoForm:transType");
		var securityNameEle = document.getElementById("infoForm:securityName");
		var wertpapierkategorieEle = document.getElementById("infoForm:securityCat");
		if (transTypeEle != null && securityNameEle != null && wertpapierkategorieEle!=null
				&& transTypeEle != undefined && securityNameEle != undefined && wertpapierkategorieEle!= undefined) {
			transTypeEle.disabled = false;
			securityNameEle.readOnly = false;
			wertpapierkategorieEle.disabled = false;
		}
	}
}

function enableFields(e){
	var selectedValue = null;
	if(e!= null && e!=undefined && e.selectedIndex!= null && e.selectedIndex!= undefined){
		selectedValue = e.options[e.selectedIndex].innerHTML;
		var orderTypeEle = document.getElementById("infoForm:orderType");
		var limitEle = document.getElementById("infoForm:limit");
		var mengeEle = document.getElementById("infoForm:amount");
		var receiveBankEle = document.getElementById("infoForm:receiveBank");
		
		if(orderTypeEle != null && orderTypeEle != null
				&& limitEle != undefined && limitEle != undefined
					&& mengeEle != undefined && mengeEle != undefined
						&& receiveBankEle != undefined && receiveBankEle != undefined){
			
			if(selectedValue=="Ubertrag"){
				orderTypeEle.disabled = true;
				limitEle.readOnly = true;
				mengeEle.readOnly = false;
				receiveBankEle.disabled = false;
				orderTypeEle.value = "";
				limitEle.value = "";
				
				ifBuySelected = false;
				ifSellOrTransferSelected = true;
			}else if(selectedValue=="Hauptversammlung"){
				mengeEle.readOnly = true;
				orderTypeEle.disabled = true;
				limitEle.readOnly = true;
				receiveBankEle.disabled = true;
				mengeEle.value = "";
				orderTypeEle.value = "";
				limitEle.value = "";
				
				ifBuySelected = false;
				ifSellOrTransferSelected = false;
			}else if(selectedValue=="Wertpapierkauf"){
				receiveBankEle.disabled = true;
				mengeEle.readOnly = false;
				orderTypeEle.disabled = false;
				limitEle.readOnly = false;
				
				ifBuySelected = true;
				ifSellOrTransferSelected = false;
			}else if(selectedValue=="Wertpapierverkauf"){
				orderTypeEle.disabled = false;
				limitEle.readOnly = false;
				mengeEle.readOnly = false;
				receiveBankEle.disabled = true;
				
				ifBuySelected = false;
				ifSellOrTransferSelected = true;
			}else{
				orderTypeEle.disabled = false;
				limitEle.readOnly = false;
				mengeEle.readOnly = false;
				receiveBankEle.disabled = true;
				
				ifBuySelected = false;
				ifSellOrTransferSelected = false;
			}
			enableLimit(e);
		}
	} 
}

function enableLimit(e){
	var selectedVal = null;
	if(e!= null && e!=undefined && e.selectedIndex!= null && e.selectedIndex!= undefined){
		selectedVal = e.options[e.selectedIndex].innerHTML;
	}
	if(selectedVal=="Bestens" || selectedVal=="Ubertrag" || selectedVal=="Hauptversammlung"){
		document.getElementById("infoForm:limit").readOnly = true;
		document.getElementById("infoForm:limit").value = "";
	}else{
		document.getElementById("infoForm:limit").readOnly = false;
		document.getElementById("infoForm:limit").value = "";
	}
}

function isSecurityAvailable(e){
	//check here if security is available If �Gesch�ftsart� = (�Verkauf� OR ��bertrag� OR �Hauptversammlung�) 
	//the chosen Security is not available in the customer's account
	var isSecurityAvailable = false;
	var selectedValue = null;
	if(e!= null && e!=undefined && e.selectedIndex!= null && e.selectedIndex!= undefined){
		selectedValue = e.options[e.selectedIndex].innerHTML;
		if(selectedValue=="Ubertrag" || selectedValue=="Hauptversammlung"){
			if(!isSecurityAvailable){
				alert("Dieses Wertpapier ist nicht im Bestand des Kunden vorhanden.");
			}
		}
	}
	
}

function setMengeVal(e){
	var selectedValue = null;
	if(e!= null && e!=undefined && e.selectedIndex!= null && e.selectedIndex!= undefined){
		selectedValue = e.options[e.selectedIndex].innerHTML;
		if(selectedValue=="Wertpapierverkauf" || selectedValue=="Ubertrag" 
			&& document.getElementById("infoForm:amount")!= null && document.getElementById("infoForm:amount") != undefined){
			document.getElementById("infoForm:amount").value=totalAmount;
		}else{
			document.getElementById("infoForm:amount").value="";
		}
	}
}

function validateMengeVal(e){
	var menge = null;
	var defaultValue = "";
	if(totalAmount!="" && totalAmount!= null && totalAmount!= undefined){
		defaultValue = totalAmount;
	}
	if(e!= null && e!=undefined){
		mengeVal = e.value;
	}
	defaultValue = ""
	if(defaultValue == "" && ifBuySelected == true){
		if (parseInt(mengeVal) % 1000 != 0 && mengeVal!="" && mengeVal!= null){
			alert("Menge steht nicht zur Verfugung");
			document.getElementById("infoForm:amount").value="";
		}
	}else if(mengeVal>defaultValue && ifSellOrTransferSelected == true){
		alert("Menge steht nicht zur Verfugung");
		document.getElementById("infoForm:amount").value=totalAmount;
	}
}

function enableSuchen(e){
	var securityName = null;
	var suchenEle = document.getElementById("infoForm:search");
	if(e!= null && e!=undefined){
		securityName = e.value;
	}
	if(securityName.length >2){
		suchenEle.disabled = false;
	}else{
		suchenEle.disabled = true;
	}
}

function search(){
	var securityNameEle = document.getElementById("infoForm:securityName");
	if(securityNameEle!= null && securityNameEle!=undefined){
		securityNameEleVal = securityNameEle.value;
	}
	
	//Add code for here Search results based on the securityNameEleVal and get searchResultsLength
	var searchResultsLength = 0;
	var minLengthForSearchResults = 1;
	var maxLengthForSearchResults = 1000;
	
	if(searchResultsLength<minLengthForSearchResults){
		alert("Es wurde kein Wertpapier gefunden.");
	}else if(searchResultsLength>maxLengthForSearchResults){
		alert("Die Suche liefert zu viele Ergebnisse. Bitte schranken Sie die Suche ein");
	}
	
}

function resetForm(){
	document.getElementById("infoForm").reset();
	document.getElementById("infoForm:transType").disabled = true;
	document.getElementById("infoForm:securityCat").disabled = true;
	document.getElementById("infoForm:orderType").disabled = true;
	document.getElementById("infoForm:receiveBank").disabled = true;
	
	document.getElementById("infoForm:securityName").readOnly = true;
	document.getElementById("infoForm:amount").readOnly = true;
	document.getElementById("infoForm:limit").readOnly = true;
	
    document.getElementById("infoForm:depotnummer").disabled = false;
}

function onSubmit(){
	var orderType=document.getElementById("infoForm:orderType");
	var selectedOrderType = orderType.options[orderType.selectedIndex].innerHTML;
	
	var geschaftsart=document.getElementById("infoForm:transType");
	var selectedGeschaftsart = geschaftsart.options[geschaftsart.selectedIndex].innerHTML;
	
	if(selectedOrderType=="Limit"){
		document.getElementById("infoForm:limit").required = true;
	}
	
	if(selectedGeschaftsart=="Ubertrag"){
		document.getElementById("infoForm:receiveBank").required = true;
	}
}









