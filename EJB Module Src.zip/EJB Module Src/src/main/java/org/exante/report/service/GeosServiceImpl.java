package org.exante.report.service;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.exante.report.pojo.Address;
import org.exante.report.pojo.NameSearchItem;
import org.exante.report.pojo.SearchByISINItem;
import org.exante.report.pojo.UploadedPDF;

@Stateless
public class GeosServiceImpl implements GeosInterface {
	private Log m_log = LogFactory.getLog(GeosServiceImpl.class);

	@Override
	public Address getAccountInfo(String accountNumber) throws Exception {
		m_log.info("GeoServiceImpl....");
		Address address = new Address();
		if ("0123456789".equalsIgnoreCase(accountNumber)) {
			address.setAccountActive(true);
			address.setAccountValid(true);
			address.setSystemDown(false);
			address.setAddressLine1("Brokerage Account");
			address.setAddressLine2("Gerhard Tscholl");
		} else if ("01234567899".equalsIgnoreCase(accountNumber)) {
			address.setAccountActive(true);
			address.setAccountValid(true);
			address.setSystemDown(false);
			address.setAddressLine1("Brokerage Account");
			address.setAddressLine2(" ");
		} else if ("012345678".equalsIgnoreCase(accountNumber)) {
			address.setAccountValid(true);
			address.setAccountActive(false);
			address.setSystemDown(false);
		} else if ("01234567".equalsIgnoreCase(accountNumber)) {
			address.setAccountValid(false);
			address.setSystemDown(false);
		} else {
			throw new RuntimeException("Connection error");
		}
		return address;
	}

	@Override
	public List<NameSearchItem> securitySearchByName(String securityName)
			throws Exception {
		List<NameSearchItem> list = new ArrayList<NameSearchItem>();
		if ("reg".equalsIgnoreCase(securityName)) {

			NameSearchItem item = new NameSearchItem();
			item.setSecurityNameValid(true);
			item.setSecurityNameValid(true);
			item.setSystemDown(false);
			item.setIsinNumber("SG1CD5000001");
			item.setSecurityTitle("Advanced holding Ltd.: Reg.Shs(Post Consolidation) oN");
			item.setSecurityType("bktien");

			NameSearchItem item1 = new NameSearchItem();
			item1.setSecurityNameValid(true);
			item1.setSecurityNameValid(true);
			item1.setSystemDown(false);
			item1.setIsinNumber("US0078651082");
			item1.setSecurityTitle("Aeropostale Inc.: Registered Shared DL-.01");
			item1.setSecurityType("Aktien ");

			NameSearchItem item2 = new NameSearchItem();
			item2.setSecurityNameValid(true);
			item2.setSecurityNameValid(true);
			item2.setSystemDown(false);
			item2.setIsinNumber("SG1CD5000001");
			item2.setSecurityTitle("Advanced holding Ltd.: Reg.Shs(Post Consolidation) oN");
			item2.setSecurityType("bktien");

			list.add(item);
			list.add(item1);
			list.add(item2);
			return list;

		} else if ("none".equalsIgnoreCase(securityName)) {
			return list;
		} else {
			throw new RuntimeException("Connection Failure");
		}
	}

	@Override
	public List<SearchByISINItem> securitySearchByISIN(String securityName)
			throws Exception {

		List<SearchByISINItem> list = new ArrayList<SearchByISINItem>();
		if ("SG1CD5000001".equalsIgnoreCase(securityName)) {

			SearchByISINItem item = new SearchByISINItem();
			item.setSecurityNameValid(true);
			item.setSecurityNameValid(true);
			item.setSystemDown(false);
			item.setAmount("0.159 EUR");
			item.setPlaceOfTrade("XETRA-Frankfurt");
			item.setLocked("Gesdert");

			SearchByISINItem item1 = new SearchByISINItem();
			item1.setSecurityNameValid(true);
			item1.setSecurityNameValid(true);
			item1.setSystemDown(false);
			item1.setAmount("0.27 SGD");
			item1.setPlaceOfTrade("Singapore Exchange SGK");
			item1.setLocked(" ");

			list.add(item);
			list.add(item1);
			return list;

		} else if ("none".equalsIgnoreCase(securityName)) {
			return list;
		} else {
			throw new RuntimeException("Connection Failure");
		}

	}

	@Override
	public List<UploadedPDF> fileLinks(String xmlFile) throws Exception {
		List<UploadedPDF> path = new ArrayList<UploadedPDF>();
		if (xmlFile != null) {
			UploadedPDF pdf = new UploadedPDF();
			pdf.setFilePath("C:/Users/admin/Desktop/innoq_ws-standards_poster_2007-02.pdf");
			UploadedPDF pdf1 = new UploadedPDF();
			pdf1.setFilePath("C:/Users/admin/Desktop/innoq_ws-standards_poster_2007-02.pdf");
			path.add(pdf);
			path.add(pdf);
			return path;

		} else {
			throw new RuntimeException("Service is down");
		}
	}
}
