package org.exante.report.pojo;

import java.io.Serializable;

public class NameSearchItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String IsinNumber;
	private String securityType;
	private String securityTitle;
	private boolean isSecurityNameValid;
	private boolean isISINNumberValid;
	private boolean isSystemDown;
	public String getIsinNumber() {
		return IsinNumber;
	}
	public void setIsinNumber(String isinNumber) {
		IsinNumber = isinNumber;
	}
	public String getSecurityType() {
		return securityType;
	}
	public void setSecurityType(String securityType) {
		this.securityType = securityType;
	}
	public String getSecurityTitle() {
		return securityTitle;
	}
	public void setSecurityTitle(String securityTitle) {
		this.securityTitle = securityTitle;
	}
	public boolean isSecurityNameValid() {
		return isSecurityNameValid;
	}
	public void setSecurityNameValid(boolean isSecurityNameValid) {
		this.isSecurityNameValid = isSecurityNameValid;
	}
	public boolean isISINNumberValid() {
		return isISINNumberValid;
	}
	public void setISINNumberValid(boolean isISINNumberValid) {
		this.isISINNumberValid = isISINNumberValid;
	}
	public boolean isSystemDown() {
		return isSystemDown;
	}
	public void setSystemDown(boolean isSystemDown) {
		this.isSystemDown = isSystemDown;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
